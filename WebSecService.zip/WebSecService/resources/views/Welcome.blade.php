@extends('layout')

@section('content')
    <h2>Welcome Page</h2>
@endsection
