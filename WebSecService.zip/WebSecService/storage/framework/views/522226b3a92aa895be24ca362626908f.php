<?php $__env->startSection('content'); ?>
    <h2>Multiplication Table (1-10)</h2>

    <?php for($i = 1; $i <= 10; $i++): ?>
        <h3>Table of <?php echo e($i); ?></h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Multiplication</th>
                    <th>Result</th>
                </tr>
            </thead>
            <tbody>
                <?php for($j = 1; $j <= 10; $j++): ?>
                    <tr>
                        <td><?php echo e($i); ?> x <?php echo e($j); ?></td>
                        <td><?php echo e($i * $j); ?></td>
                    </tr>
                <?php endfor; ?>
            </tbody>
        </table>
    <?php endfor; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSec230104579\WebSecService\resources\views/multiplication-table.blade.php ENDPATH**/ ?>