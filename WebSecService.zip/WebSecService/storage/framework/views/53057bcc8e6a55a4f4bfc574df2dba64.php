

<?php $__env->startSection('content'); ?>
    <h2>Welcome Page</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSec230104579\WebSecService\resources\views/Welcome.blade.php ENDPATH**/ ?>