

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Create New Grade</h1>
    <form action="<?php echo e(route('grades.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="course_name">Course Name</label>
            <input type="text" name="course_name" id="course_name" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="grade">Grade</label>
            <input type="text" name="grade" id="grade" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="credit_hours">Credit Hours</label>
            <input type="number" name="credit_hours" id="credit_hours" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="term">Term</label>
            <input type="text" name="term" id="term" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Create Grade</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSec230104579\WebSecService\resources\views/grades/create.blade.php ENDPATH**/ ?>