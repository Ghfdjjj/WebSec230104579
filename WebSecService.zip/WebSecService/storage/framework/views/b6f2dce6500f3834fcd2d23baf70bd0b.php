

<?php $__env->startSection('content'); ?>
    <h2>Prime Numbers</h2>
    <div class="card">
        <div class="card-header">Prime Numbers</div>
        <div class="card-body">
            <?php
                function isPrime($number) {
                    if ($number < 2) return false;
                    for ($i = 2; $i <= sqrt($number); $i++) {
                        if ($number % $i == 0) return false;
                    }
                    return true;
                }
            ?>

            <?php $__currentLoopData = range(1, 100); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isPrime($i)): ?>
                    <span class="badge bg-primary p-2 m-1"><?php echo e($i); ?></span>
                <?php else: ?>
                    <span class="badge bg-secondary p-2 m-1"><?php echo e($i); ?></span>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSec230104579\WebSecService\resources\views/prime_numbers.blade.php ENDPATH**/ ?>