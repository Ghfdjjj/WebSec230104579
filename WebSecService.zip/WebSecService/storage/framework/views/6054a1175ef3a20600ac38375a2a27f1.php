

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Grade</h1>
    <form action="<?php echo e(route('grades.update', $grade->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    
    <!-- Course Name Field -->
    <div class="form-group">
        <label for="course_name">Course Name</label>
        <input type="text" name="course_name" id="course_name" class="form-control" value="<?php echo e($grade->course_name); ?>" required>
        <?php $__errorArgs = ['course_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Grade Field -->
    <div class="form-group">
        <label for="grade">Grade</label>
        <input type="text" name="grade" id="grade" class="form-control" value="<?php echo e($grade->grade); ?>" required>
        <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Credit Hours Field -->
    <div class="form-group">
        <label for="credit_hours">Credit Hours</label>
        <input type="number" name="credit_hours" id="credit_hours" class="form-control" value="<?php echo e($grade->credit_hours); ?>" required>
        <?php $__errorArgs = ['credit_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Term Field -->
    <div class="form-group">
        <label for="term">Term</label>
        <input type="text" name="term" id="term" class="form-control" value="<?php echo e($grade->term); ?>" required>
        <?php $__errorArgs = ['term'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Submit Button -->
    <button type="submit" class="btn btn-primary mt-3">Update Grade</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\WebSec230104579\WebSecService\resources\views/grades/edit.blade.php ENDPATH**/ ?>