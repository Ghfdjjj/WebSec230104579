<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Service</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container mt-4">

    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">Home</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('even-numbers') ? 'active' : ''); ?>" href="<?php echo e(url('/even-numbers')); ?>">Even Numbers</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('prime-numbers') ? 'active' : ''); ?>" href="<?php echo e(url('/prime-numbers')); ?>">Prime Numbers</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('multiplication-table') ? 'active' : ''); ?>" href="<?php echo e(url('/multiplication-table')); ?>">Multiplication Table</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('MiniTest') ? 'active' : ''); ?>" href="<?php echo e(url('/MiniTest')); ?>">MiniTest</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('Transcript') ? 'active' : ''); ?>" href="<?php echo e(url('/Transcript')); ?>">Transcript</a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('grades') ? 'active' : ''); ?>" href="<?php echo e(url('/grades')); ?>">Grades</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('users') ? 'active' : ''); ?>" href="<?php echo e(url('/users')); ?>">Users</a>
        </li>
    </ul>

    <div class="mt-3">
        <div class="card card-body">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\WebSec230104579\WebSecService\resources\views/layout.blade.php ENDPATH**/ ?>